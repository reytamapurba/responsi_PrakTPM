package com.example.lat_responsi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
